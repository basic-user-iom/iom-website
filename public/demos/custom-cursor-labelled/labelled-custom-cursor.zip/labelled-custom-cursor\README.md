# Labelled custom cursor — complete code pack

IOM experiment: precision tip + inertial ring with labelled modes
(VIEW, PLAY, LOOK, EXPLORE / ENTER 3D, START, DRAG, …).

## Contents

- `demo/` — standalone lab (open via a local static server)
- `react-module/` — parked React/TypeScript module snapshot (labelled v1)

## Live

- Lab: https://iobjectm.com/demos/custom-cursor-labelled/
- Case study: https://iobjectm.com/case-studies/labelled-custom-cursor/

## Quick start (demo)

```bash
npx serve demo
```

Hover playground targets; the usage panel updates to the active `data-cursor` mode.

## Markup

```html
<a href="/path" data-cursor="explore" data-cursor-label="ENTER 3D">Enter</a>
<article data-cursor="view">…</article>
<button type="button" data-cursor="play">Play</button>
```

Modes: `view | play | pause | explore | look | drag | start | external | link | native`

## License note

Code from Interactive Object Media (iobjectm.com). Use as reference for your own projects;
keep attribution if you redistribute the pack.
